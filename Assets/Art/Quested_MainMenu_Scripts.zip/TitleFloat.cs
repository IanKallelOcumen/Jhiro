using UnityEngine;

/// <summary>
/// Gentle floating/tilt/scale idle motion for a logo/title image.
/// Call TriggerBump() to give it a quick buoyant hop when buttons are pressed.
/// Attach this to the TitleLogo (an Image under the Canvas).
/// </summary>
[DisallowMultipleComponent]
[RequireComponent(typeof(RectTransform))]
public class TitleFloat : MonoBehaviour
{
    [Header("Idle Float (tweak in Inspector)")]
    [Tooltip("Vertical bob amplitude in pixels.")]
    public float amplitudeY = 10f;
    [Tooltip("Bob cycles per second.")]
    public float speedY = 0.6f;
    [Tooltip("Z rotation amplitude in degrees.")]
    public float rotAmplitude = 1.5f;
    [Tooltip("Rotation cycles per second.")]
    public float rotSpeed = 0.35f;
    [Tooltip("Uniform scale pulse amplitude (e.g., 0.01 = 1%).")]
    public float scaleAmplitude = 0.01f;
    [Tooltip("Scale cycles per second.")]
    public float scaleSpeed = 0.5f;
    [Tooltip("Use unscaled time so it animates even if timescale changes.")]
    public bool useUnscaledTime = true;

    [Header("Bump (on button press)")]
    [Tooltip("How high the extra hop goes (pixels).")]
    public float bumpHeight = 12f;
    [Tooltip("How quickly it pops up (seconds).")]
    public float bumpOutTime = 0.10f;
    [Tooltip("How quickly it falls back (seconds).")]
    public float bumpBackTime = 0.22f;
    [Tooltip("Optional extra rotation kick during bump (degrees).")]
    public float bumpRotate = 2.0f;

    RectTransform _rt;
    Vector2 _basePos;
    Vector3 _baseScale;
    float _phase;
    float _extraYOffset;    // transient extra offset from bumps
    float _extraZRot;       // transient extra rotation kick
    bool _isBumping;

    void Awake()
    {
        _rt = GetComponent<RectTransform>();
        _basePos = _rt.anchoredPosition;
        _baseScale = _rt.localScale;
        _phase = Random.value * Mathf.PI * 2f; // desync if multiple
    }

    void Update()
    {
        float t = useUnscaledTime ? Time.unscaledTime : Time.time;
        float dt = useUnscaledTime ? Time.unscaledDeltaTime : Time.deltaTime;

        // Idle sine motions
        float y = Mathf.Sin((t + _phase) * Mathf.PI * 2f * speedY) * amplitudeY;
        float z = Mathf.Sin((t + _phase * 0.7f) * Mathf.PI * 2f * rotSpeed) * rotAmplitude;
        float scl = 1f + Mathf.Sin((t + _phase * 0.4f) * Mathf.PI * 2f * scaleSpeed) * scaleAmplitude;

        // Apply idle + transient extras
        _rt.anchoredPosition = new Vector2(_basePos.x, _basePos.y + y + _extraYOffset);
        _rt.localEulerAngles = new Vector3(0f, 0f, z + _extraZRot);
        _rt.localScale = _baseScale * scl;

        // Smoothly decay extra rotation (in case multiple bumps stack)
        if (!_isBumping && Mathf.Abs(_extraZRot) > 0.001f)
            _extraZRot = Mathf.MoveTowards(_extraZRot, 0f, dt * 90f);
    }

    /// <summary>
    /// Public method to trigger a quick upward hop + tiny rotation.
    /// Call from button event scripts (e.g., ButtonBumpTitle).
    /// </summary>
    public void TriggerBump()
    {
        if (gameObject.activeInHierarchy)
            StartCoroutine(BumpRoutine());
    }

    System.Collections.IEnumerator BumpRoutine()
    {
        _isBumping = true;
        float t = 0f;
        float start = _extraYOffset;
        float peak = Mathf.Max(bumpHeight, start + bumpHeight * 0.7f); // allow stacking
        float rKick = bumpRotate;

        // Up
        while (t < bumpOutTime)
        {
            float u = t / Mathf.Max(0.0001f, bumpOutTime);
            // Ease-out (quadratic)
            float eased = 1f - (1f - u) * (1f - u);
            _extraYOffset = Mathf.Lerp(start, peak, eased);
            _extraZRot = rKick * (1f - u);
            t += useUnscaledTime ? Time.unscaledDeltaTime : Time.deltaTime;
            yield return null;
        }

        // Down
        t = 0f;
        float top = _extraYOffset;
        while (t < bumpBackTime)
        {
            float u = t / Mathf.Max(0.0001f, bumpBackTime);
            // Ease-in (quadratic)
            float eased = u * u;
            _extraYOffset = Mathf.Lerp(top, 0f, eased);
            _extraZRot = Mathf.Lerp(_extraZRot, 0f, u);
            t += useUnscaledTime ? Time.unscaledDeltaTime : Time.deltaTime;
            yield return null;
        }

        _extraYOffset = 0f;
        _isBumping = false;
    }
}
