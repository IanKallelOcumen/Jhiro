using UnityEngine;

/// <summary>
/// Keeps a RectTransform inside the platform's safe area (notches, rounded corners, system bars).
/// Add this to any panel that must avoid cutouts. Works in Edit and Play mode.
/// </summary>
[ExecuteAlways]
[RequireComponent(typeof(RectTransform))]
public class SafeArea : MonoBehaviour
{
    private Rect _lastSafe, _lastScreen;
    private RectTransform _rt;

    void OnEnable() { _rt = GetComponent<RectTransform>(); Apply(); }
    void OnRectTransformDimensionsChange() { Apply(); }

    private void Apply()
    {
        if (_rt == null) return;

        Rect sa = Screen.safeArea;
        Rect scr = new Rect(0, 0, Screen.width, Screen.height);

        if (sa == _lastSafe && scr == _lastScreen) return;
        _lastSafe = sa; _lastScreen = scr;

        Vector2 min = sa.position;
        Vector2 max = sa.position + sa.size;
        min.x /= Screen.width;  min.y /= Screen.height;
        max.x /= Screen.width;  max.y /= Screen.height;

        _rt.anchorMin = min;
        _rt.anchorMax = max;
        _rt.offsetMin = Vector2.zero;
        _rt.offsetMax = Vector2.zero;
    }
}
