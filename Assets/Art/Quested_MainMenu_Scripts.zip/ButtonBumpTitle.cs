using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

/// <summary>
/// Attach to any Button to make it 'poke' the TitleFloat on press.
/// Works with mouse/touch. OnPointerDown is used for instant feedback.
/// </summary>
[RequireComponent(typeof(Button))]
public class ButtonBumpTitle : MonoBehaviour, IPointerDownHandler
{
    [Tooltip("TitleFloat to bump. If null, it will auto-find one in the scene.")]
    public TitleFloat target;

    void Awake()
    {
        if (target == null)
            target = FindObjectOfType<TitleFloat>();
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        if (target != null)
            target.TriggerBump();
    }
}
