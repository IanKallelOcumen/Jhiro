using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;
using UnityEngine.Audio;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

/// <summary>
/// Quested main menu logic:
/// - Panel switching (Main / About / Leaderboard)
/// - Sound toggle persisted via PlayerPrefs
/// - Play loads a gameplay scene
/// - Exit hidden on iOS, quits on Android/PC, stops playmode in Editor
/// - Builds a sample leaderboard (replace with your backend later)
/// </summary>
public class MainMenuController : MonoBehaviour
{
    [Header("Panels")]
    [SerializeField] private GameObject panelMain;
    [SerializeField] private GameObject panelAbout;
    [SerializeField] private GameObject panelLeaderboard;

    [Header("UI")]
    [SerializeField] private Toggle soundToggle;
    [SerializeField] private Button exitButton; // auto-hidden on iOS

    [Header("Audio (optional)")]
    [SerializeField] private AudioMixer masterMixer; // Expose "MasterVolume"
    [SerializeField] private AudioSource musicSource;
    private const string MixerParam = "MasterVolume";
    private const string PrefKeySound = "Quested_Sound";

    [Header("Leaderboard")]
    [SerializeField] private Transform leaderboardContent;   // ScrollView/Viewport/Content
    [SerializeField] private GameObject leaderboardRowPrefab;

    [Header("Scenes")]
    [SerializeField] private string gameSceneName = "Game"; // set your gameplay scene name

    void Awake()
    {
#if UNITY_IOS
        if (exitButton) exitButton.gameObject.SetActive(false);
#endif
        // Load persisted sound state (default: ON)
        bool soundOn = PlayerPrefs.GetInt(PrefKeySound, 1) == 1;
        ApplySound(soundOn);
        if (soundToggle != null)
        {
            soundToggle.isOn = soundOn;
            soundToggle.onValueChanged.AddListener(OnSoundToggled);
        }
    }

    void Start() => Show(panelMain);

    // ---------------- Buttons ----------------
    public void OnPlay()
    {
        if (string.IsNullOrEmpty(gameSceneName))
        {
            Debug.LogError("Set gameSceneName in MainMenuController.");
            return;
        }
        SceneManager.LoadScene(gameSceneName);
    }
    public void OnAbout()        => Show(panelAbout);
    public void OnLeaderboard()  { Show(panelLeaderboard); BuildSampleLeaderboard(); }
    public void OnBack()         => Show(panelMain);
    public void OnExit()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    }

    // ---------------- Sound ----------------
    private void OnSoundToggled(bool isOn)
    {
        ApplySound(isOn);
        PlayerPrefs.SetInt(PrefKeySound, isOn ? 1 : 0);
        PlayerPrefs.Save();
    }
    private void ApplySound(bool isOn)
    {
        if (masterMixer != null)
            masterMixer.SetFloat(MixerParam, isOn ? 0f : -80f);
        else
            AudioListener.volume = isOn ? 1f : 0f;

        if (musicSource != null && musicSource.clip != null)
        {
            if (isOn && !musicSource.isPlaying) musicSource.Play();
            if (!isOn && musicSource.isPlaying) musicSource.Pause();
        }
    }

    // ---------------- Panels ----------------
    private void Show(GameObject only)
    {
        if (panelMain)        panelMain.SetActive(false);
        if (panelAbout)       panelAbout.SetActive(false);
        if (panelLeaderboard) panelLeaderboard.SetActive(false);
        if (only)             only.SetActive(true);
    }

    // ---------------- Leaderboard (sample) ----------------
    private class Entry
    {
        public int r; public string n; public int s;
        public Entry(int r, string n, int s) { this.r = r; this.n = n; this.s = s; }
    }

    private void BuildSampleLeaderboard()
    {
        if (!leaderboardContent || !leaderboardRowPrefab) return;

        // Clear old rows
        for (int i = leaderboardContent.childCount - 1; i >= 0; i--)
            Destroy(leaderboardContent.GetChild(i).gameObject);

        var data = new List<Entry>
        {
            new Entry(1,"Torchbearers", 2450),
            new Entry(2,"Rune Seekers", 2230),
            new Entry(3,"Stone Wardens", 2105),
            new Entry(4,"Crypt Sprinters", 1990),
            new Entry(5,"Goblin Dodgers", 1875),
            new Entry(6,"Mimic Whisperers", 1760),
            new Entry(7,"Trap Dancers", 1685),
            new Entry(8,"Potion Hoarders", 1600),
            new Entry(9,"Key Finders", 1510),
            new Entry(10,"Torch Droppers", 1420),
        };

        foreach (var e in data)
        {
            var row = Instantiate(leaderboardRowPrefab, leaderboardContent);
            var rank  = row.transform.Find("RankText")?.GetComponent<TMP_Text>();
            var name  = row.transform.Find("NameText")?.GetComponent<TMP_Text>();
            var score = row.transform.Find("ScoreText")?.GetComponent<TMP_Text>();
            if (rank)  rank.text  = e.r.ToString();
            if (name)  name.text  = e.n;
            if (score) score.text = e.s.ToString("N0");
        }
    }

    // ---------------- Android Back key ----------------
    void Update()
    {
#if UNITY_ANDROID && ENABLE_INPUT_SYSTEM
        if (Keyboard.current != null && Keyboard.current.escapeKey.wasPressedThisFrame)
        {
            if (panelAbout.activeSelf || panelLeaderboard.activeSelf) OnBack();
            else OnExit();
        }
#elif UNITY_ANDROID
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (panelAbout.activeSelf || panelLeaderboard.activeSelf) OnBack();
            else OnExit();
        }
#endif
    }
}
